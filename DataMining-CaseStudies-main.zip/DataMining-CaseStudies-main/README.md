# Case Studies for Data Mining Course  - UI(N)

* Case Study 01 Applied Data Mining: Exploratory Data Analysis (EDA)
* Case Study 02 Applied Data Mining: Clustering Analysis
* Case Study 03 Applied Data Mining: ...
* 
